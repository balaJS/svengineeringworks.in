<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">S.V.Engineering</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index2.php">Add Page</a></li>
      <li><a href="list.php">List Page</a></li>
      <li><a href="backend.php?logout=logout">Log out</a></li>
    </ul>
  </div>
</nav>
